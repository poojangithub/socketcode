## SF Chat Websocket Server

See the blog post [Websocket Chat in Salesforce with Lightning Web Components](https://blog.jamigibbs.com/websockets-in-salesforce-with-lightning-web-components/) for more details.

Deploy this app for yourself on Heroku by clicking the button below:

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/jamigibbs/sf-chat-websocket-server)
